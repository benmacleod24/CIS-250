# Homework 2

Benjamin MacLeod
<br>
March 8th, 2023
<br>
CIS 250

## Overview

`Employee management system` used to sort & review employees at a company. The data source is a `comma seperated list` that is parsed into two specific data structures.
<br>
`Circle Class` the circle class program will ask you to enter the radius us a circle and output some information about that circle.
<br>
`Triva Game` the trivia program is super simple to use, all you have to do is enter the names for player one and two. Then read the intro and type `yes` when your ready to begin. From there it will ask player one 5 questions, then player two 5 questions. Once completed it will annouce the winner and end the program.

## Project Thoughts

These project where pretty fun, mainly the empoloyee management system because I was able to leverage the power of classes and organizing my data in a easy to use way.
