# Doubly Linked List - Homework 03

Benjamin MacLeod
March 22th, 2023
CIS 153

## Overview

This homework was somewhat of a tough one, because there were no language or syntax errors that I could use to debug any issues I was having. Once I got passed that part it wasn't too bad to do and came pretty naturally.

## Issues

The issues I did run into were lost connections between nodes but once I sat down and visualized what was happening between the nodes I was able to write my code according to what I needed.
